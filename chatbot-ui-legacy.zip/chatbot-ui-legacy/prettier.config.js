module.exports = {
  trailingComma: 'all',
  singleQuote: true,
  plugins: [require('prettier-plugin-tailwindcss')]
};
